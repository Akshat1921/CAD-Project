from django.apps import AppConfig


class ImagegalleryConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'imagegallery'
